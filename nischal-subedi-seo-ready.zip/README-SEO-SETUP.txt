Nischal Subedi — SEO-ready GitHub Pages files

Files:
- index.html — your existing website with SEO metadata, canonical URL, Open Graph/Twitter metadata, robots directives, and Person structured data.
- robots.txt — allows search crawlers and points them to the sitemap.
- sitemap.xml — lists the homepage for search engines.

Upload all three files to the ROOT of:
nischalsubedi2580-prog.github.io
on the main branch.

Important:
Keep the homepage filename exactly "index.html".
